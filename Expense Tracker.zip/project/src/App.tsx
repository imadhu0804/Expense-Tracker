import React from 'react';
import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout/Layout';
import FloatingActionButton from './components/UI/FloatingActionButton';
import NotificationToast from './components/Notifications/NotificationToast';
import PinSetup from './components/Auth/PinSetup';
import PinLogin from './components/Auth/PinLogin';
import Dashboard from './pages/Dashboard';
import AddExpense from './pages/AddExpense';
import ExpenseList from './pages/ExpenseList';
import Budget from './pages/Budget';
import { authService } from './services/authService';
import { themeService } from './services/themeService';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [hasPin, setHasPin] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Apply theme on app start
    themeService.applyTheme();
    
    // Register service worker for PWA
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js')
        .then(() => console.log('SW registered'))
        .catch(() => console.log('SW registration failed'));
    }

    // Check authentication status
    setIsAuthenticated(authService.isAuthenticated());
    setHasPin(authService.hasPin());
    setLoading(false);
  }, []);

  const handlePinSetup = (pin: string) => {
    authService.setupPin(pin);
    setHasPin(true);
    setIsAuthenticated(true);
  };

  const handleLogin = (pin: string) => {
    const success = authService.authenticate(pin);
    if (success) {
      setIsAuthenticated(true);
    }
    return success;
  };

  const handleReset = () => {
    authService.resetPin();
    localStorage.clear();
    setHasPin(false);
    setIsAuthenticated(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center"
        >
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading ExpenseTracker...</p>
        </motion.div>
      </div>
    );
  }

  if (!hasPin) {
    return <PinSetup onSetup={handlePinSetup} />;
  }

  if (!isAuthenticated) {
    return <PinLogin onLogin={handleLogin} onReset={handleReset} />;
  }

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        <Router>
          <Layout>
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/add" element={<AddExpense />} />
              <Route path="/list" element={<ExpenseList />} />
              <Route path="/budget" element={<Budget />} />
            </Routes>
          </Layout>
          <FloatingActionButton />
          <NotificationToast />
        </Router>
      </motion.div>
    </AnimatePresence>
  );
}

export default App;