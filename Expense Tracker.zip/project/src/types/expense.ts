export interface Expense {
  id: number;
  title: string;
  amount: number;
  date: string;
  category: string;
  notes?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface ExpenseFormData {
  title: string;
  amount: number;
  date: string;
  category: string;
  notes: string;
}

export interface ExpenseFilters {
  startDate?: string;
  endDate?: string;
  category?: string;
  search?: string;
}

export interface DashboardStats {
  totalExpenses: number;
  monthlyTotal: number;
  categoryData: CategoryData[];
  trendData: TrendData[];
}

export interface CategoryData {
  name: string;
  value: number;
  color: string;
}

export interface TrendData {
  month: string;
  amount: number;
}

export interface BudgetGoal {
  id: number;
  category: string;
  monthlyLimit: number;
  currentSpent: number;
  month: string;
  year: number;
}

export interface RecurringExpense {
  id: number;
  title: string;
  amount: number;
  category: string;
  frequency: 'daily' | 'weekly' | 'monthly';
  nextDue: string;
  isActive: boolean;
}

export interface Theme {
  name: string;
  primary: string;
  secondary: string;
  accent: string;
  background: string;
  surface: string;
  text: string;
}

export interface CurrencyRate {
  USD: number;
  INR: number;
  EUR: number;
  GBP: number;
}

export interface UserPreferences {
  currency: 'USD' | 'INR' | 'EUR' | 'GBP';
  theme: string;
  dateFormat: 'US' | 'IN' | 'EU';
  notifications: boolean;
  autoCategories: boolean;
}

export interface AuthState {
  isAuthenticated: boolean;
  pin?: string;
}

export const EXPENSE_CATEGORIES = [
  'Food',
  'Transport',
  'Health',
  'Entertainment',
  'Shopping',
  'Bills',
  'Education',
  'Travel',
  'Other'
] as const;

export type ExpenseCategory = typeof EXPENSE_CATEGORIES[number];