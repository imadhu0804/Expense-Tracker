import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { DollarSign, TrendingUp, Calendar, PieChart, Download, Target, Brain, Plus } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import StatCard from '../components/Dashboard/StatCard';
import ExpenseChart from '../components/Dashboard/ExpenseChart';
import TrendChart from '../components/Dashboard/TrendChart';
import SpendingStreak from '../components/Dashboard/SpendingStreak';
import ExportModal from '../components/Export/ExportModal';
import ConfettiEffect from '../components/UI/ConfettiEffect';
import ExpenseInsights from '../components/SmartFeatures/ExpenseInsights';
import { Expense, CategoryData, TrendData } from '../types/expense';
import { expenseService } from '../services/expenseService';
import { budgetService } from '../services/budgetService';
import { currencyService } from '../services/currencyService';
import { themeService } from '../services/themeService';
import { formatCurrency, getCurrentMonth, getLastSixMonths } from '../utils/dateHelpers';
import { generateCategoryData, generateTrendData } from '../utils/chartHelpers';
import { showSuccessToast } from '../components/Notifications/NotificationToast';

const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [categoryData, setCategoryData] = useState<CategoryData[]>([]);
  const [trendData, setTrendData] = useState<TrendData[]>([]);
  const [showExportModal, setShowExportModal] = useState(false);
  const [budgetAlerts, setBudgetAlerts] = useState<string[]>([]);
  const [showConfetti, setShowConfetti] = useState(false);
  const [showInsights, setShowInsights] = useState(false);
  const [streakData, setStreakData] = useState({
    currentStreak: 0,
    bestStreak: 0,
    budgetGoalsMet: 0,
    totalBudgets: 0
  });

  useEffect(() => {
    fetchExpenses();
    checkBudgetAlerts();
    fetchCurrencyRates();
  }, []);

  const fetchExpenses = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await expenseService.getAllExpenses();
      setExpenses(data);
      
      // Generate chart data
      setCategoryData(generateCategoryData(data));
      setTrendData(generateTrendData(data, getLastSixMonths()));
    } catch (err) {
      setError('Failed to fetch expenses. Please try again.');
      console.error('Error fetching expenses:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchCurrencyRates = async () => {
    try {
      await currencyService.fetchRates();
    } catch (error) {
      console.error('Failed to fetch currency rates:', error);
    }
  };

  const checkBudgetAlerts = async () => {
    try {
      const budgets = await budgetService.getAllBudgets();
      const currentDate = new Date();
      const currentMonth = `${currentDate.getFullYear()}-${(currentDate.getMonth() + 1).toString().padStart(2, '0')}`;
      
      const alerts: string[] = [];
      let budgetGoalsMet = 0;
      let totalBudgets = budgets.filter(b => b.month === currentMonth).length;
      
      budgets.forEach(budget => {
        if (budget.month === currentMonth) {
          const percentage = (budget.currentSpent / budget.monthlyLimit) * 100;
          if (percentage > 100) {
            alerts.push(`${budget.category} budget exceeded by ${formatCurrency(budget.currentSpent - budget.monthlyLimit)}`);
          } else if (percentage > 80) {
            alerts.push(`${budget.category} budget is ${percentage.toFixed(0)}% used`);
            budgetGoalsMet++;
          } else {
            budgetGoalsMet++;
          }
        }
      });
      
      setBudgetAlerts(alerts);
      
      // Update streak data
      setStreakData(prev => ({
        ...prev,
        budgetGoalsMet,
        totalBudgets,
        currentStreak: budgetGoalsMet === totalBudgets && totalBudgets > 0 ? prev.currentStreak + 1 : 0
      }));
      
      // Show confetti if all budgets are met
      if (budgetGoalsMet === totalBudgets && totalBudgets > 0) {
        setShowConfetti(true);
        showSuccessToast('🎉 All budget goals met this month!');
      }
    } catch (error) {
      console.error('Error checking budget alerts:', error);
    }
  };

  const calculateStats = () => {
    const currentMonth = getCurrentMonth();
    const currentMonthExpenses = expenses.filter(
      expense => expense.date >= currentMonth.start && expense.date <= currentMonth.end
    );
    
    const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);
    const monthlyTotal = currentMonthExpenses.reduce((sum, expense) => sum + expense.amount, 0);
    const expenseCount = expenses.length;
    
    return {
      totalExpenses,
      monthlyTotal,
      expenseCount,
      avgExpense: expenseCount > 0 ? totalExpenses / expenseCount : 0
    };
  };

  const stats = calculateStats();

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
              <div className="animate-pulse space-y-4">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-8 bg-gray-200 rounded w-1/2"></div>
              </div>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
            <div className="animate-pulse h-64 bg-gray-200 rounded"></div>
          </div>
          <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
            <div className="animate-pulse h-64 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <div className="text-red-600 mb-4">{error}</div>
        <button
          onClick={fetchExpenses}
          className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors"
        >
          Retry
        </button>
      </div>
    );
  }

  // Show welcome screen when no expenses exist
  if (expenses.length === 0) {
    return (
      <div className="space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-16"
        >
          <div className="mx-auto w-24 h-24 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mb-8">
            <DollarSign className="w-12 h-12 text-white" />
          </div>
          
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Welcome to ExpenseTracker Pro! 🎉
          </h1>
          
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Take control of your finances with smart expense tracking, budget goals, and insightful analytics. 
            Start by adding your first expense to see the magic happen!
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto mb-12">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-white rounded-xl p-6 shadow-lg border border-gray-100"
            >
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4 mx-auto">
                <PieChart className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Smart Analytics</h3>
              <p className="text-gray-600 text-sm">
                Visualize your spending patterns with beautiful charts and insights
              </p>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-white rounded-xl p-6 shadow-lg border border-gray-100"
            >
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4 mx-auto">
                <Target className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Budget Goals</h3>
              <p className="text-gray-600 text-sm">
                Set monthly budgets and track your progress towards financial goals
              </p>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-white rounded-xl p-6 shadow-lg border border-gray-100"
            >
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4 mx-auto">
                <Brain className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">AI Features</h3>
              <p className="text-gray-600 text-sm">
                Voice input, receipt scanning, and smart category suggestions
              </p>
            </motion.div>
          </div>
          
          <div className="space-y-4">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => navigate('/add')}
              className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-4 rounded-xl font-semibold text-lg shadow-lg hover:shadow-xl transition-all duration-200 flex items-center space-x-3 mx-auto"
            >
              <Plus className="w-6 h-6" />
              <span>Add Your First Expense</span>
            </motion.button>
            
            <p className="text-gray-500 text-sm">
              Or use the floating action button in the bottom right for quick entry
            </p>
          </div>
          
          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl mx-auto">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">₹0</div>
              <div className="text-xs text-gray-500">Total Expenses</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">0</div>
              <div className="text-xs text-gray-500">Transactions</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">0</div>
              <div className="text-xs text-gray-500">Categories</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">0</div>
              <div className="text-xs text-gray-500">Budget Goals</div>
            </div>
          </div>
        </motion.div>
      </div>
    );
  }
  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-1">Overview of your financial activity</p>
        </div>
        <div className="flex space-x-3">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowInsights(true)}
            className="flex items-center space-x-2 bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors"
          >
            <Brain className="w-4 h-4" />
            <span>Insights</span>
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowExportModal(true)}
            className="flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>Export</span>
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={fetchExpenses}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Refresh
          </motion.button>
        </div>
      </motion.div>

      {/* Budget Alerts */}
      {budgetAlerts.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-yellow-50 border border-yellow-200 rounded-lg p-4"
        >
          <div className="flex items-center space-x-2 mb-2">
            <Target className="w-5 h-5 text-yellow-600" />
            <h3 className="font-medium text-yellow-800">Budget Alerts</h3>
          </div>
          <ul className="space-y-1">
            {budgetAlerts.map((alert, index) => (
              <li key={index} className="text-sm text-yellow-700">• {alert}</li>
            ))}
          </ul>
        </motion.div>
      )}

      <ConfettiEffect 
        trigger={showConfetti} 
        onComplete={() => setShowConfetti(false)} 
      />

      {/* Stats Cards */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
      >
        {[
          {
            title: "Total Expenses",
            value: formatCurrency(stats.totalExpenses),
            icon: DollarSign,
            color: "bg-blue-600"
          },
          {
            title: "This Month",
            value: formatCurrency(stats.monthlyTotal),
            icon: Calendar,
            color: "bg-green-600"
          },
          {
            title: "Total Transactions",
            value: stats.expenseCount.toString(),
            icon: TrendingUp,
            color: "bg-purple-600"
          },
          {
            title: "Average Expense",
            value: formatCurrency(stats.avgExpense),
            icon: PieChart,
            color: "bg-orange-600"
          }
        ].map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 * index }}
          >
            <StatCard {...stat} />
          </motion.div>
        ))}
      </motion.div>

      {/* Charts */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="grid grid-cols-1 lg:grid-cols-3 gap-6"
      >
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
        >
          <ExpenseChart data={categoryData} />
        </motion.div>
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.6 }}
        >
          <TrendChart data={trendData} />
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
        >
          <SpendingStreak {...streakData} />
        </motion.div>
      </motion.div>

      <ExportModal
        isOpen={showExportModal}
        onClose={() => setShowExportModal(false)}
        expenses={expenses}
      />
      
      <ExpenseInsights
        expenses={expenses}
        isOpen={showInsights}
        onClose={() => setShowInsights(false)}
      />
    </div>
  );
};

export default Dashboard;