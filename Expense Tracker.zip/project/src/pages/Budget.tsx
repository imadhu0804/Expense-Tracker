import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Plus, Target } from 'lucide-react';
import BudgetCard from '../components/Budget/BudgetCard';
import BudgetModal from '../components/Budget/BudgetModal';
import { BudgetGoal } from '../types/expense';
import { budgetService } from '../services/budgetService';
import { expenseService } from '../services/expenseService';

const Budget: React.FC = () => {
  const [budgets, setBudgets] = useState<BudgetGoal[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingBudget, setEditingBudget] = useState<BudgetGoal | null>(null);

  useEffect(() => {
    fetchBudgets();
  }, []);

  const fetchBudgets = async () => {
    try {
      setLoading(true);
      const budgetData = await budgetService.getAllBudgets();
      
      // Update current spent amounts
      const expenses = await expenseService.getAllExpenses();
      const currentDate = new Date();
      const currentMonth = currentDate.getMonth() + 1;
      const currentYear = currentDate.getFullYear();
      
      for (const budget of budgetData) {
        const [year, month] = budget.month.split('-').map(Number);
        if (year === currentYear && month === currentMonth) {
          const categoryExpenses = expenses.filter(exp => 
            exp.category === budget.category &&
            exp.date.startsWith(budget.month)
          );
          const totalSpent = categoryExpenses.reduce((sum, exp) => sum + exp.amount, 0);
          await budgetService.updateSpentAmount(budget.category, month, year, totalSpent);
        }
      }
      
      // Fetch updated budgets
      const updatedBudgets = await budgetService.getAllBudgets();
      setBudgets(updatedBudgets);
    } catch (error) {
      console.error('Error fetching budgets:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveBudget = async (category: string, amount: number) => {
    try {
      const currentDate = new Date();
      const currentMonth = currentDate.getMonth() + 1;
      const currentYear = currentDate.getFullYear();
      
      await budgetService.setBudget(category, amount, currentMonth, currentYear);
      fetchBudgets();
    } catch (error) {
      console.error('Error saving budget:', error);
    }
  };

  const handleEditBudget = (budget: BudgetGoal) => {
    setEditingBudget(budget);
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditingBudget(null);
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-48 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Budget Goals</h1>
          <p className="text-gray-600 mt-2">Set and track your monthly spending limits</p>
        </div>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setShowModal(true)}
          className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Add Budget</span>
        </motion.button>
      </motion.div>

      {budgets.length === 0 ? (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-12"
        >
          <div className="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
            <Target className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Budget Goals Set</h3>
          <p className="text-gray-600 mb-4">Start by setting budget limits for your expense categories</p>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowModal(true)}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Create Your First Budget
          </motion.button>
        </motion.div>
      ) : (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {budgets.map((budget, index) => (
            <motion.div
              key={budget.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <BudgetCard budget={budget} onEdit={handleEditBudget} />
            </motion.div>
          ))}
        </motion.div>
      )}

      <BudgetModal
        isOpen={showModal}
        onClose={handleCloseModal}
        onSave={handleSaveBudget}
        initialCategory={editingBudget?.category}
        initialAmount={editingBudget?.monthlyLimit}
      />
    </div>
  );
};

export default Budget;