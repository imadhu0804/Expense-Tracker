import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import ExpenseForm from '../components/Forms/ExpenseForm';
import { ExpenseFormData } from '../types/expense';
import { expenseService } from '../services/expenseService';
import { showSuccessToast, showErrorToast } from '../components/Notifications/NotificationToast';

const AddExpense: React.FC = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const navigate = useNavigate();

  const handleSubmit = async (formData: ExpenseFormData) => {
    try {
      setIsLoading(true);
      setError(null);
      setSuccess(null);
      
      await expenseService.createExpense(formData);
      
      showSuccessToast('💰 Expense added successfully!');
      setTimeout(() => {
        navigate('/list');
      }, 1500);
    } catch (err) {
      showErrorToast('Failed to add expense. Please try again.');
      console.error('Error creating expense:', err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <h1 className="text-2xl font-bold text-gray-900">Add New Expense</h1>
        <p className="text-gray-600 mt-2">
          Enter the details of your expense below.
        </p>
      </motion.div>

      {/* Error Message */}

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-white rounded-lg shadow-md p-6 border border-gray-200"
      >
        <ExpenseForm
          onSubmit={handleSubmit}
          onCancel={() => navigate('/list')}
          isLoading={isLoading}
          submitLabel="Add Expense"
        />
      </motion.div>
    </div>
  );
};

export default AddExpense;