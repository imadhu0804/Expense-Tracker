import { CategoryData, TrendData, Expense } from '../types/expense';

export const getCategoryColors = (): Record<string, string> => ({
  Food: '#FF6B6B',
  Transport: '#4ECDC4',
  Health: '#45B7D1',
  Entertainment: '#96CEB4',
  Shopping: '#FFEAA7',
  Bills: '#DDA0DD',
  Education: '#98D8C8',
  Travel: '#F7DC6F',
  Other: '#AED6F1'
});

export const generateCategoryData = (expenses: Expense[]): CategoryData[] => {
  const categoryTotals: Record<string, number> = {};
  const colors = getCategoryColors();

  expenses.forEach(expense => {
    categoryTotals[expense.category] = (categoryTotals[expense.category] || 0) + expense.amount;
  });

  return Object.entries(categoryTotals)
    .map(([name, value]) => ({
      name,
      value,
      color: colors[name] || colors.Other
    }))
    .sort((a, b) => b.value - a.value);
};

export const generateTrendData = (expenses: Expense[], months: Array<{ start: string; end: string; name: string }>): TrendData[] => {
  return months.map(month => {
    const monthExpenses = expenses.filter(expense => 
      expense.date >= month.start && expense.date <= month.end
    );
    
    const totalAmount = monthExpenses.reduce((sum, expense) => sum + expense.amount, 0);
    
    return {
      month: month.name,
      amount: totalAmount
    };
  });
};