import { format, startOfMonth, endOfMonth, subMonths, parseISO } from 'date-fns';
import { themeService } from '../services/themeService';

export const formatDate = (date: string | Date): string => {
  const dateObj = typeof date === 'string' ? parseISO(date) : date;
  return format(dateObj, 'yyyy-MM-dd');
};

export const formatDisplayDate = (date: string | Date): string => {
  return themeService.formatDate(date);
};

export const formatCurrency = (amount: number): string => {
  const preferences = themeService.getPreferences();
  
  // Always format in Indian style for INR
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
};

export const getCurrentMonth = (): { start: string; end: string } => {
  const now = new Date();
  return {
    start: formatDate(startOfMonth(now)),
    end: formatDate(endOfMonth(now))
  };
};

export const getLastSixMonths = (): Array<{ start: string; end: string; name: string }> => {
  const months = [];
  const now = new Date();
  
  for (let i = 5; i >= 0; i--) {
    const monthDate = subMonths(now, i);
    months.push({
      start: formatDate(startOfMonth(monthDate)),
      end: formatDate(endOfMonth(monthDate)),
      name: format(monthDate, 'MMM yyyy')
    });
  }
  
  return months;
};