import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Lock, AlertCircle } from 'lucide-react';

interface PinLoginProps {
  onLogin: (pin: string) => boolean;
  onReset: () => void;
}

const PinLogin: React.FC<PinLoginProps> = ({ onLogin, onReset }) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [attempts, setAttempts] = useState(0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (pin.length < 4) {
      setError('Please enter your PIN');
      return;
    }
    
    const success = onLogin(pin);
    if (!success) {
      setError('Incorrect PIN');
      setAttempts(prev => prev + 1);
      setPin('');
    }
  };

  const handleReset = () => {
    if (window.confirm('This will delete all your data. Are you sure?')) {
      onReset();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-2xl shadow-xl p-8 w-full max-w-md"
      >
        <div className="text-center mb-8">
          <div className="mx-auto w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4">
            <Lock className="w-8 h-8 text-blue-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900">Welcome Back</h1>
          <p className="text-gray-600 mt-2">Enter your PIN to access your expenses</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Enter PIN
            </label>
            <input
              type="password"
              value={pin}
              onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-center text-2xl tracking-widest"
              placeholder="••••"
              maxLength={8}
              autoFocus
            />
          </div>

          {error && (
            <motion.div
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center space-x-2 text-red-600 text-sm"
            >
              <AlertCircle className="w-4 h-4" />
              <span>{error}</span>
            </motion.div>
          )}

          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            type="submit"
            className="w-full bg-blue-600 text-white py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors"
          >
            Unlock
          </motion.button>
        </form>

        {attempts >= 3 && (
          <div className="mt-6 text-center">
            <button
              onClick={handleReset}
              className="text-sm text-red-600 hover:text-red-800 underline"
            >
              Forgot PIN? Reset App Data
            </button>
          </div>
        )}

        <div className="mt-6 text-xs text-gray-500 text-center">
          Your data is stored securely on this device
        </div>
      </motion.div>
    </div>
  );
};

export default PinLogin;