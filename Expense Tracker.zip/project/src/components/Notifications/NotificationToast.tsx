import React from 'react';
import toast, { Toaster } from 'react-hot-toast';
import { CheckCircle, AlertCircle, XCircle, Info } from 'lucide-react';

export const showSuccessToast = (message: string) => {
  toast.success(message, {
    icon: <CheckCircle className="w-5 h-5 text-green-500" />,
    style: {
      background: '#F0FDF4',
      color: '#166534',
      border: '1px solid #BBF7D0'
    }
  });
};

export const showErrorToast = (message: string) => {
  toast.error(message, {
    icon: <XCircle className="w-5 h-5 text-red-500" />,
    style: {
      background: '#FEF2F2',
      color: '#991B1B',
      border: '1px solid #FECACA'
    }
  });
};

export const showWarningToast = (message: string) => {
  toast(message, {
    icon: <AlertCircle className="w-5 h-5 text-yellow-500" />,
    style: {
      background: '#FFFBEB',
      color: '#92400E',
      border: '1px solid #FED7AA'
    }
  });
};

export const showInfoToast = (message: string) => {
  toast(message, {
    icon: <Info className="w-5 h-5 text-blue-500" />,
    style: {
      background: '#EFF6FF',
      color: '#1E40AF',
      border: '1px solid #DBEAFE'
    }
  });
};

const NotificationToast: React.FC = () => {
  return (
    <Toaster
      position="top-right"
      toastOptions={{
        duration: 4000,
        style: {
          borderRadius: '12px',
          padding: '16px',
          fontSize: '14px',
          fontWeight: '500'
        }
      }}
    />
  );
};

export default NotificationToast;