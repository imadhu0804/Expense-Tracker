import React from 'react';
import { motion } from 'framer-motion';
import { Target, TrendingUp, TrendingDown, AlertTriangle } from 'lucide-react';
import { BudgetGoal } from '../../types/expense';
import { formatCurrency } from '../../utils/dateHelpers';

interface BudgetCardProps {
  budget: BudgetGoal;
  onEdit: (budget: BudgetGoal) => void;
}

const BudgetCard: React.FC<BudgetCardProps> = ({ budget, onEdit }) => {
  const percentage = (budget.currentSpent / budget.monthlyLimit) * 100;
  const remaining = budget.monthlyLimit - budget.currentSpent;
  const isOverBudget = percentage > 100;
  const isNearLimit = percentage > 80 && percentage <= 100;

  const getStatusColor = () => {
    if (isOverBudget) return 'text-red-600';
    if (isNearLimit) return 'text-yellow-600';
    return 'text-green-600';
  };

  const getProgressColor = () => {
    if (isOverBudget) return 'bg-red-500';
    if (isNearLimit) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  const getIcon = () => {
    if (isOverBudget) return <TrendingDown className="w-5 h-5" />;
    if (isNearLimit) return <AlertTriangle className="w-5 h-5" />;
    return <TrendingUp className="w-5 h-5" />;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.02 }}
      className="bg-white rounded-lg shadow-md p-6 border border-gray-200 cursor-pointer"
      onClick={() => onEdit(budget)}
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-blue-100 rounded-lg">
            <Target className="w-5 h-5 text-blue-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">{budget.category}</h3>
            <p className="text-sm text-gray-500">{budget.month}</p>
          </div>
        </div>
        <div className={`flex items-center space-x-1 ${getStatusColor()}`}>
          {getIcon()}
          <span className="text-sm font-medium">
            {percentage.toFixed(0)}%
          </span>
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">Spent</span>
          <span className="font-medium">{formatCurrency(budget.currentSpent)}</span>
        </div>
        
        <div className="w-full bg-gray-200 rounded-full h-2">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${Math.min(percentage, 100)}%` }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className={`h-2 rounded-full ${getProgressColor()}`}
          />
        </div>

        <div className="flex justify-between text-sm">
          <span className="text-gray-600">Budget</span>
          <span className="font-medium">{formatCurrency(budget.monthlyLimit)}</span>
        </div>

        <div className="pt-2 border-t border-gray-100">
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">Remaining</span>
            <span className={`font-semibold ${remaining >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {formatCurrency(Math.abs(remaining))}
              {remaining < 0 && ' over'}
            </span>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default BudgetCard;