import React from 'react';
import { motion } from 'framer-motion';
import { Trophy, Target, TrendingUp } from 'lucide-react';

interface SpendingStreakProps {
  currentStreak: number;
  bestStreak: number;
  budgetGoalsMet: number;
  totalBudgets: number;
}

const SpendingStreak: React.FC<SpendingStreakProps> = ({
  currentStreak,
  bestStreak,
  budgetGoalsMet,
  totalBudgets
}) => {
  const streakPercentage = totalBudgets > 0 ? (budgetGoalsMet / totalBudgets) * 100 : 0;

  return (
    <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
      <div className="flex items-center space-x-3 mb-4">
        <div className="p-2 bg-yellow-100 rounded-lg">
          <Trophy className="w-5 h-5 text-yellow-600" />
        </div>
        <h3 className="text-lg font-semibold text-gray-900">Budget Achievements</h3>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <TrendingUp className="w-4 h-4 text-green-600" />
            <span className="text-sm text-gray-600">Current Streak</span>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-green-600">{currentStreak}</div>
            <div className="text-xs text-gray-500">days on budget</div>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Trophy className="w-4 h-4 text-yellow-600" />
            <span className="text-sm text-gray-600">Best Streak</span>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-yellow-600">{bestStreak}</div>
            <div className="text-xs text-gray-500">days record</div>
          </div>
        </div>

        <div className="pt-4 border-t border-gray-100">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-600">Budget Goals Met</span>
            <span className="text-sm font-medium">{budgetGoalsMet}/{totalBudgets}</span>
          </div>
          
          <div className="w-full bg-gray-200 rounded-full h-2">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${streakPercentage}%` }}
              transition={{ duration: 1, ease: "easeOut" }}
              className="bg-gradient-to-r from-green-500 to-blue-500 h-2 rounded-full"
            />
          </div>
          
          <div className="text-center mt-2">
            <span className="text-xs text-gray-500">
              {streakPercentage.toFixed(0)}% of budgets on track
            </span>
          </div>
        </div>

        {currentStreak >= 7 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-gradient-to-r from-yellow-50 to-orange-50 p-3 rounded-lg border border-yellow-200"
          >
            <div className="flex items-center space-x-2">
              <Trophy className="w-5 h-5 text-yellow-600" />
              <span className="text-sm font-medium text-yellow-800">
                Great job! You're on a {currentStreak}-day budget streak! 🎉
              </span>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default SpendingStreak;