import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mic, MicOff, Volume2 } from 'lucide-react';
import { ExpenseFormData } from '../../types/expense';
import { smartCategoryService } from '../../services/smartCategoryService';

interface VoiceExpenseInputProps {
  onExpenseDetected: (expense: Partial<ExpenseFormData>) => void;
  isOpen: boolean;
  onClose: () => void;
}

const VoiceExpenseInput: React.FC<VoiceExpenseInputProps> = ({
  onExpenseDetected,
  isOpen,
  onClose
}) => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [confidence, setConfidence] = useState(0);

  useEffect(() => {
    if (!isOpen) {
      setIsListening(false);
      setTranscript('');
    }
  }, [isOpen]);

  const startListening = () => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      const recognition = new SpeechRecognition();
      
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = 'en-IN';

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: any) => {
        const current = event.resultIndex;
        const transcript = event.results[current][0].transcript;
        const confidence = event.results[current][0].confidence;
        
        setTranscript(transcript);
        setConfidence(confidence);
        
        if (event.results[current].isFinal) {
          parseVoiceInput(transcript);
        }
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } else {
      alert('Speech recognition not supported in this browser');
    }
  };

  const parseVoiceInput = (text: string) => {
    // Simple parsing logic for Indian context
    const lowerText = text.toLowerCase();
    
    // Extract amount (look for rupees, rs, or numbers)
    const amountMatch = lowerText.match(/(?:rupees?|rs\.?|₹)\s*(\d+(?:,\d+)*(?:\.\d+)?)|(\d+(?:,\d+)*(?:\.\d+)?)\s*(?:rupees?|rs\.?|₹)/i);
    const amount = amountMatch ? parseFloat(amountMatch[1] || amountMatch[2]) : 0;

    // Extract title (everything before amount or common keywords)
    let title = text;
    if (amountMatch) {
      title = text.replace(amountMatch[0], '').trim();
    }
    
    // Clean up common voice artifacts
    title = title.replace(/^(i spent|spent|paid|bought|purchase)/i, '').trim();
    title = title.replace(/(for|on|at)$/i, '').trim();
    
    // Suggest category
    const category = smartCategoryService.suggestCategory(title);

    const expense: Partial<ExpenseFormData> = {
      title: title || 'Voice Expense',
      amount,
      category,
      date: new Date().toISOString().split('T')[0],
      notes: `Voice input: "${text}"`
    };

    onExpenseDetected(expense);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-white rounded-2xl p-8 w-full max-w-md text-center"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="mb-6">
            <motion.div
              animate={{ scale: isListening ? [1, 1.1, 1] : 1 }}
              transition={{ repeat: isListening ? Infinity : 0, duration: 1 }}
              className={`mx-auto w-20 h-20 rounded-full flex items-center justify-center ${
                isListening ? 'bg-red-100' : 'bg-blue-100'
              }`}
            >
              {isListening ? (
                <Mic className="w-10 h-10 text-red-600" />
              ) : (
                <MicOff className="w-10 h-10 text-blue-600" />
              )}
            </motion.div>
          </div>

          <h2 className="text-xl font-bold text-gray-900 mb-2">
            Voice Expense Input
          </h2>
          
          <p className="text-gray-600 mb-6">
            {isListening 
              ? 'Listening... Say something like "I spent 500 rupees on groceries"'
              : 'Click the microphone to start recording'
            }
          </p>

          {transcript && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-4 p-3 bg-gray-50 rounded-lg"
            >
              <p className="text-sm text-gray-700">"{transcript}"</p>
              {confidence > 0 && (
                <p className="text-xs text-gray-500 mt-1">
                  Confidence: {Math.round(confidence * 100)}%
                </p>
              )}
            </motion.div>
          )}

          <div className="flex space-x-3">
            <button
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={startListening}
              disabled={isListening}
              className={`flex-1 px-4 py-2 rounded-lg text-white transition-colors ${
                isListening 
                  ? 'bg-red-600 hover:bg-red-700' 
                  : 'bg-blue-600 hover:bg-blue-700'
              }`}
            >
              <div className="flex items-center justify-center space-x-2">
                <Volume2 className="w-4 h-4" />
                <span>{isListening ? 'Listening...' : 'Start Recording'}</span>
              </div>
            </motion.button>
          </div>

          <div className="mt-4 text-xs text-gray-500">
            <p>💡 Try saying: "I spent 250 rupees on chai and snacks"</p>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default VoiceExpenseInput;