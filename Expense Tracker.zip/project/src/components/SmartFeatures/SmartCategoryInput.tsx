import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Brain, Check } from 'lucide-react';
import { EXPENSE_CATEGORIES } from '../../types/expense';
import { smartCategoryService } from '../../services/smartCategoryService';

interface SmartCategoryInputProps {
  title: string;
  notes: string;
  value: string;
  onChange: (category: string) => void;
  disabled?: boolean;
}

const SmartCategoryInput: React.FC<SmartCategoryInputProps> = ({
  title,
  notes,
  value,
  onChange,
  disabled = false
}) => {
  const [suggestion, setSuggestion] = useState<string | null>(null);
  const [confidence, setConfidence] = useState(0);
  const [showSuggestion, setShowSuggestion] = useState(false);

  useEffect(() => {
    if (title.trim().length > 2) {
      const suggested = smartCategoryService.suggestCategory(title, notes);
      const confidenceLevel = smartCategoryService.getConfidenceLevel(title, suggested, notes);
      
      if (suggested !== value && confidenceLevel > 0.3) {
        setSuggestion(suggested);
        setConfidence(confidenceLevel);
        setShowSuggestion(true);
      } else {
        setShowSuggestion(false);
      }
    } else {
      setShowSuggestion(false);
    }
  }, [title, notes, value]);

  const handleAcceptSuggestion = () => {
    if (suggestion) {
      onChange(suggestion);
      setShowSuggestion(false);
    }
  };

  const getConfidenceColor = () => {
    if (confidence > 0.7) return 'text-green-600 bg-green-100';
    if (confidence > 0.5) return 'text-yellow-600 bg-yellow-100';
    return 'text-blue-600 bg-blue-100';
  };

  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-gray-700 mb-2">
        Category *
      </label>
      
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        disabled={disabled}
        className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
      >
        {EXPENSE_CATEGORIES.map(category => (
          <option key={category} value={category}>
            {category}
          </option>
        ))}
      </select>

      <AnimatePresence>
        {showSuggestion && suggestion && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className={`p-3 rounded-lg border ${getConfidenceColor()}`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Brain className="w-4 h-4" />
                <span className="text-sm font-medium">
                  Smart suggestion: {suggestion}
                </span>
                <span className="text-xs px-2 py-1 rounded-full bg-white bg-opacity-50">
                  {Math.round(confidence * 100)}% confident
                </span>
              </div>
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={handleAcceptSuggestion}
                className="flex items-center space-x-1 text-sm font-medium hover:underline"
              >
                <Check className="w-4 h-4" />
                <span>Accept</span>
              </motion.button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default SmartCategoryInput;