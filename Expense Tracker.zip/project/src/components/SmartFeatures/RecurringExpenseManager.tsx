import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Repeat, Plus, Edit, Trash2, Clock } from 'lucide-react';
import { RecurringExpense } from '../../types/expense';
import { recurringExpenseService } from '../../services/recurringExpenseService';
import { currencyService } from '../../services/currencyService';
import { themeService } from '../../services/themeService';

interface RecurringExpenseManagerProps {
  isOpen: boolean;
  onClose: () => void;
}

const RecurringExpenseManager: React.FC<RecurringExpenseManagerProps> = ({ isOpen, onClose }) => {
  const [recurringExpenses, setRecurringExpenses] = useState<RecurringExpense[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingExpense, setEditingExpense] = useState<RecurringExpense | null>(null);
  const preferences = themeService.getPreferences();

  useEffect(() => {
    if (isOpen) {
      fetchRecurringExpenses();
    }
  }, [isOpen]);

  const fetchRecurringExpenses = async () => {
    const expenses = await recurringExpenseService.getAllRecurring();
    setRecurringExpenses(expenses);
  };

  const formatCurrency = (amount: number) => {
    return currencyService.formatCurrency(amount, preferences.currency);
  };

  const getFrequencyLabel = (frequency: RecurringExpense['frequency']) => {
    const labels = {
      daily: 'Daily',
      weekly: 'Weekly',
      monthly: 'Monthly'
    };
    return labels[frequency];
  };

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-white rounded-2xl p-6 w-full max-w-2xl max-h-[80vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-purple-100 rounded-lg">
              <Repeat className="w-5 h-5 text-purple-600" />
            </div>
            <h2 className="text-xl font-bold text-gray-900">Recurring Expenses</h2>
          </div>
          <button
            onClick={() => setShowForm(true)}
            className="flex items-center space-x-2 bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Add Recurring</span>
          </button>
        </div>

        {recurringExpenses.length === 0 ? (
          <div className="text-center py-8">
            <Clock className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No Recurring Expenses</h3>
            <p className="text-gray-600">Set up recurring expenses to automate your tracking</p>
          </div>
        ) : (
          <div className="space-y-4">
            {recurringExpenses.map((expense) => (
              <motion.div
                key={expense.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-4 border border-gray-200 rounded-lg hover:border-purple-300 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h3 className="font-medium text-gray-900">{expense.title}</h3>
                    <div className="flex items-center space-x-4 mt-1 text-sm text-gray-600">
                      <span>{formatCurrency(expense.amount)}</span>
                      <span>{expense.category}</span>
                      <span>{getFrequencyLabel(expense.frequency)}</span>
                      <span>Next: {themeService.formatDate(expense.nextDue)}</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => setEditingExpense(expense)}
                      className="p-2 text-gray-400 hover:text-blue-600 transition-colors"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => recurringExpenseService.deleteRecurring(expense.id)}
                      className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </motion.div>
    </motion.div>
  );
};

export default RecurringExpenseManager;