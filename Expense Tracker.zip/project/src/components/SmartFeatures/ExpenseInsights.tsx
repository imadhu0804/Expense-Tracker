import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Brain, TrendingUp, TrendingDown, AlertTriangle, Lightbulb, X } from 'lucide-react';
import { Expense } from '../../types/expense';
import { formatCurrency } from '../../utils/dateHelpers';

interface ExpenseInsightsProps {
  expenses: Expense[];
  isOpen: boolean;
  onClose: () => void;
}

interface Insight {
  type: 'warning' | 'tip' | 'trend' | 'achievement';
  title: string;
  description: string;
  icon: React.ComponentType<any>;
  color: string;
  action?: string;
}

const ExpenseInsights: React.FC<ExpenseInsightsProps> = ({ expenses, isOpen, onClose }) => {
  const [insights, setInsights] = useState<Insight[]>([]);

  useEffect(() => {
    if (isOpen && expenses.length > 0) {
      generateInsights();
    }
  }, [isOpen, expenses]);

  const generateInsights = () => {
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    
    const thisMonthExpenses = expenses.filter(exp => {
      const expDate = new Date(exp.date);
      return expDate.getMonth() === currentMonth && expDate.getFullYear() === currentYear;
    });

    const lastMonthExpenses = expenses.filter(exp => {
      const expDate = new Date(exp.date);
      const lastMonth = currentMonth === 0 ? 11 : currentMonth - 1;
      const lastMonthYear = currentMonth === 0 ? currentYear - 1 : currentYear;
      return expDate.getMonth() === lastMonth && expDate.getFullYear() === lastMonthYear;
    });

    const newInsights: Insight[] = [];

    // Spending trend analysis
    const thisMonthTotal = thisMonthExpenses.reduce((sum, exp) => sum + exp.amount, 0);
    const lastMonthTotal = lastMonthExpenses.reduce((sum, exp) => sum + exp.amount, 0);
    
    if (lastMonthTotal > 0) {
      const change = ((thisMonthTotal - lastMonthTotal) / lastMonthTotal) * 100;
      if (change > 20) {
        newInsights.push({
          type: 'warning',
          title: 'Spending Increased',
          description: `Your spending increased by ${change.toFixed(1)}% compared to last month (${formatCurrency(thisMonthTotal - lastMonthTotal)} more)`,
          icon: TrendingUp,
          color: 'text-red-600 bg-red-100',
          action: 'Review your budget'
        });
      } else if (change < -10) {
        newInsights.push({
          type: 'achievement',
          title: 'Great Savings!',
          description: `You saved ${formatCurrency(lastMonthTotal - thisMonthTotal)} compared to last month (${Math.abs(change).toFixed(1)}% less)`,
          icon: TrendingDown,
          color: 'text-green-600 bg-green-100'
        });
      }
    }

    // Category analysis
    const categoryTotals: Record<string, number> = {};
    thisMonthExpenses.forEach(exp => {
      categoryTotals[exp.category] = (categoryTotals[exp.category] || 0) + exp.amount;
    });

    const topCategory = Object.entries(categoryTotals).sort(([,a], [,b]) => b - a)[0];
    if (topCategory && topCategory[1] > thisMonthTotal * 0.4) {
      newInsights.push({
        type: 'warning',
        title: 'High Category Spending',
        description: `${topCategory[0]} accounts for ${((topCategory[1] / thisMonthTotal) * 100).toFixed(1)}% of your spending (${formatCurrency(topCategory[1])})`,
        icon: AlertTriangle,
        color: 'text-yellow-600 bg-yellow-100',
        action: 'Consider reducing expenses in this category'
      });
    }

    // Spending pattern insights
    const weekdaySpending = thisMonthExpenses.filter(exp => {
      const day = new Date(exp.date).getDay();
      return day >= 1 && day <= 5; // Monday to Friday
    }).reduce((sum, exp) => sum + exp.amount, 0);

    const weekendSpending = thisMonthExpenses.filter(exp => {
      const day = new Date(exp.date).getDay();
      return day === 0 || day === 6; // Saturday and Sunday
    }).reduce((sum, exp) => sum + exp.amount, 0);

    if (weekendSpending > weekdaySpending && thisMonthExpenses.length > 10) {
      newInsights.push({
        type: 'tip',
        title: 'Weekend Spending Pattern',
        description: `You spend more on weekends (${formatCurrency(weekendSpending)}) than weekdays (${formatCurrency(weekdaySpending)})`,
        icon: Lightbulb,
        color: 'text-blue-600 bg-blue-100',
        action: 'Plan weekend activities within budget'
      });
    }

    // Frequency insights
    const avgDailyExpenses = thisMonthExpenses.length / new Date().getDate();
    if (avgDailyExpenses > 3) {
      newInsights.push({
        type: 'tip',
        title: 'Frequent Transactions',
        description: `You make ${avgDailyExpenses.toFixed(1)} transactions per day on average. Consider consolidating purchases.`,
        icon: Brain,
        color: 'text-purple-600 bg-purple-100',
        action: 'Try weekly shopping instead of daily'
      });
    }

    // Achievement for consistent tracking
    if (expenses.length > 50) {
      newInsights.push({
        type: 'achievement',
        title: 'Tracking Champion!',
        description: `You've recorded ${expenses.length} expenses. Consistent tracking leads to better financial control.`,
        icon: Brain,
        color: 'text-green-600 bg-green-100'
      });
    }

    setInsights(newInsights);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-white rounded-2xl p-6 w-full max-w-2xl max-h-[80vh] overflow-y-auto"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-purple-100 rounded-lg">
                <Brain className="w-5 h-5 text-purple-600" />
              </div>
              <h2 className="text-xl font-bold text-gray-900">Smart Insights</h2>
            </div>
            <button
              onClick={onClose}
              className="text-gray-500 hover:text-gray-700"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {insights.length === 0 ? (
            <div className="text-center py-8">
              <Brain className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Analyzing Your Spending</h3>
              <p className="text-gray-600">Add more expenses to get personalized insights</p>
            </div>
          ) : (
            <div className="space-y-4">
              {insights.map((insight, index) => {
                const Icon = insight.icon;
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="p-4 border border-gray-200 rounded-lg hover:border-gray-300 transition-colors"
                  >
                    <div className="flex items-start space-x-3">
                      <div className={`p-2 rounded-lg ${insight.color}`}>
                        <Icon className="w-5 h-5" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-900 mb-1">
                          {insight.title}
                        </h3>
                        <p className="text-sm text-gray-600 mb-2">
                          {insight.description}
                        </p>
                        {insight.action && (
                          <p className="text-xs text-blue-600 font-medium">
                            💡 {insight.action}
                          </p>
                        )}
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}

          <div className="mt-6 p-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <Lightbulb className="w-4 h-4 text-purple-600" />
              <span className="text-sm font-medium text-purple-800">Pro Tip</span>
            </div>
            <p className="text-xs text-purple-700">
              Regular expense tracking helps identify spending patterns and opportunities for savings. 
              Check insights weekly for better financial awareness!
            </p>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default ExpenseInsights;