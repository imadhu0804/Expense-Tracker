import React from 'react';
import { motion } from 'framer-motion';
import { Palette } from 'lucide-react';
import { THEMES, themeService } from '../../services/themeService';

interface ThemeSelectorProps {
  isOpen: boolean;
  onClose: () => void;
}

const ThemeSelector: React.FC<ThemeSelectorProps> = ({ isOpen, onClose }) => {
  const preferences = themeService.getPreferences();

  const handleThemeChange = (themeName: string) => {
    themeService.updatePreferences({ theme: themeName });
    onClose();
  };

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-white rounded-2xl p-6 w-full max-w-md"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center space-x-3 mb-6">
          <div className="p-2 bg-blue-100 rounded-lg">
            <Palette className="w-5 h-5 text-blue-600" />
          </div>
          <h2 className="text-xl font-bold text-gray-900">Choose Theme</h2>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {Object.entries(THEMES).map(([key, theme]) => (
            <motion.button
              key={key}
              onClick={() => handleThemeChange(key)}
              className={`p-4 rounded-lg border-2 transition-all ${
                preferences.theme === key
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="flex items-center space-x-3 mb-2">
                <div
                  className="w-6 h-6 rounded-full"
                  style={{ backgroundColor: theme.primary }}
                />
                <span className="font-medium text-gray-900">{theme.name}</span>
              </div>
              <div className="flex space-x-1">
                <div
                  className="w-4 h-4 rounded"
                  style={{ backgroundColor: theme.primary }}
                />
                <div
                  className="w-4 h-4 rounded"
                  style={{ backgroundColor: theme.secondary }}
                />
                <div
                  className="w-4 h-4 rounded"
                  style={{ backgroundColor: theme.accent }}
                />
              </div>
            </motion.button>
          ))}
        </div>
      </motion.div>
    </motion.div>
  );
};

export default ThemeSelector;