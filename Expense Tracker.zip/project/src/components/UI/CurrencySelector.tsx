import React from 'react';
import { motion } from 'framer-motion';
import { DollarSign } from 'lucide-react';
import { themeService } from '../../services/themeService';
import { currencyService } from '../../services/currencyService';

interface CurrencySelectorProps {
  isOpen: boolean;
  onClose: () => void;
}

const currencies = [
  { code: 'INR', name: 'Indian Rupee', symbol: '₹', flag: '🇮🇳' },
  { code: 'USD', name: 'US Dollar', symbol: '$', flag: '🇺🇸' },
  { code: 'EUR', name: 'Euro', symbol: '€', flag: '🇪🇺' },
  { code: 'GBP', name: 'British Pound', symbol: '£', flag: '🇬🇧' }
];

const CurrencySelector: React.FC<CurrencySelectorProps> = ({ isOpen, onClose }) => {
  const preferences = themeService.getPreferences();
  const rates = currencyService.getRates();

  const handleCurrencyChange = (currency: any) => {
    themeService.updatePreferences({ currency: currency.code });
    onClose();
  };

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-white rounded-2xl p-6 w-full max-w-md"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center space-x-3 mb-6">
          <div className="p-2 bg-green-100 rounded-lg">
            <DollarSign className="w-5 h-5 text-green-600" />
          </div>
          <h2 className="text-xl font-bold text-gray-900">Select Currency</h2>
        </div>

        <div className="space-y-3">
          {currencies.map((currency) => (
            <motion.button
              key={currency.code}
              onClick={() => handleCurrencyChange(currency)}
              className={`w-full p-4 rounded-lg border-2 transition-all text-left ${
                preferences.currency === currency.code
                  ? 'border-green-500 bg-green-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <span className="text-2xl">{currency.flag}</span>
                  <div>
                    <div className="font-medium text-gray-900">
                      {currency.code} - {currency.name}
                    </div>
                    <div className="text-sm text-gray-600">
                      Symbol: {currency.symbol}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm text-gray-600">Rate</div>
                  <div className="font-medium">
                    {rates[currency.code as keyof typeof rates].toFixed(2)}
                  </div>
                </div>
              </div>
            </motion.button>
          ))}
        </div>

        <div className="mt-4 p-3 bg-blue-50 rounded-lg">
          <p className="text-xs text-blue-700">
            Exchange rates are updated daily. Conversions are approximate.
          </p>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default CurrencySelector;