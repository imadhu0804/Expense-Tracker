import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Coffee, Car, ShoppingBag, Utensils, X, Mic, Camera, Brain } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import VoiceExpenseInput from '../SmartFeatures/VoiceExpenseInput';
import ExpensePhotoCapture from '../SmartFeatures/ExpensePhotoCapture';
import { ExpenseFormData } from '../../types/expense';
import { expenseService } from '../../services/expenseService';
import { showSuccessToast } from '../Notifications/NotificationToast';

interface QuickAddOption {
  category: string;
  icon: React.ComponentType<any>;
  color: string;
  defaultTitle: string;
}

const quickAddOptions: QuickAddOption[] = [
  { category: 'Food', icon: Utensils, color: 'bg-red-500', defaultTitle: 'Chai & Snacks' },
  { category: 'Transport', icon: Car, color: 'bg-blue-500', defaultTitle: 'Auto/Bus Fare' },
  { category: 'Shopping', icon: ShoppingBag, color: 'bg-purple-500', defaultTitle: 'Online Shopping' },
  { category: 'Entertainment', icon: Coffee, color: 'bg-green-500', defaultTitle: 'Movie/Fun' }
];

const FloatingActionButton: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [showVoiceInput, setShowVoiceInput] = useState(false);
  const [showPhotoCapture, setShowPhotoCapture] = useState(false);
  const navigate = useNavigate();

  const handleQuickAdd = (option: QuickAddOption) => {
    navigate('/add', { 
      state: { 
        category: option.category, 
        title: option.defaultTitle 
      } 
    });
    setIsOpen(false);
  };

  const handleVoiceExpense = async (expense: Partial<ExpenseFormData>) => {
    try {
      await expenseService.createExpense(expense as ExpenseFormData);
      showSuccessToast('🎤 Voice expense added successfully!');
    } catch (error) {
      console.error('Error adding voice expense:', error);
    }
  };

  const handlePhotoExpense = async (expense: Partial<ExpenseFormData>) => {
    try {
      await expenseService.createExpense(expense as ExpenseFormData);
      showSuccessToast('📸 Receipt scanned and expense added!');
    } catch (error) {
      console.error('Error adding photo expense:', error);
    }
  };

  return (
    <>
      <div className="fixed bottom-6 right-6 z-50">
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="absolute bottom-16 right-0 space-y-3"
            >
              {/* Smart Features */}
              <motion.button
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ delay: 0 * 0.1 }}
                onClick={() => {
                  setShowVoiceInput(true);
                  setIsOpen(false);
                }}
                className="flex items-center space-x-3 bg-green-600 text-white px-4 py-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-200"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Mic className="w-5 h-5" />
                <span className="text-sm font-medium whitespace-nowrap">Voice Input</span>
              </motion.button>

              <motion.button
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ delay: 1 * 0.1 }}
                onClick={() => {
                  setShowPhotoCapture(true);
                  setIsOpen(false);
                }}
                className="flex items-center space-x-3 bg-indigo-600 text-white px-4 py-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-200"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Camera className="w-5 h-5" />
                <span className="text-sm font-medium whitespace-nowrap">Scan Receipt</span>
              </motion.button>

              {/* Quick Add Options */}
              {quickAddOptions.map((option, index) => {
                const Icon = option.icon;
                return (
                  <motion.button
                    key={option.category}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ delay: (index + 2) * 0.1 }}
                    onClick={() => handleQuickAdd(option)}
                    className={`flex items-center space-x-3 ${option.color} text-white px-4 py-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-200 group`}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="text-sm font-medium whitespace-nowrap">
                      {option.category}
                    </span>
                  </motion.button>
                );
              })}
            </motion.div>
          )}
        </AnimatePresence>

        <motion.button
          onClick={() => setIsOpen(!isOpen)}
          className="w-14 h-14 bg-blue-600 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-200 flex items-center justify-center"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          animate={{ rotate: isOpen ? 45 : 0 }}
        >
          {isOpen ? <X className="w-6 h-6" /> : <Plus className="w-6 h-6" />}
        </motion.button>
      </div>

      <VoiceExpenseInput
        isOpen={showVoiceInput}
        onClose={() => setShowVoiceInput(false)}
        onExpenseDetected={handleVoiceExpense}
      />

      <ExpensePhotoCapture
        isOpen={showPhotoCapture}
        onClose={() => setShowPhotoCapture(false)}
        onExpenseDetected={handlePhotoExpense}
      />
    </>
  );
};

export default FloatingActionButton;