import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Download, FileText, Database, BarChart3 } from 'lucide-react';
import { Expense } from '../../types/expense';
import { exportService } from '../../services/exportService';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  expenses: Expense[];
}

const ExportModal: React.FC<ExportModalProps> = ({ isOpen, onClose, expenses }) => {
  const [isExporting, setIsExporting] = useState(false);

  const handleExport = async (type: 'csv' | 'json' | 'summary') => {
    setIsExporting(true);
    
    try {
      const timestamp = new Date().toISOString().split('T')[0];
      
      switch (type) {
        case 'csv':
          exportService.exportToCSV(expenses, `expenses-${timestamp}.csv`);
          break;
        case 'json':
          exportService.exportToJSON(expenses, `expenses-${timestamp}.json`);
          break;
        case 'summary':
          exportService.exportSummaryReport(expenses, `expense-summary-${timestamp}.txt`);
          break;
      }
      
      setTimeout(() => {
        setIsExporting(false);
        onClose();
      }, 1000);
    } catch (error) {
      console.error('Export failed:', error);
      setIsExporting(false);
    }
  };

  const exportOptions = [
    {
      type: 'csv' as const,
      title: 'CSV Spreadsheet',
      description: 'Export as CSV file for Excel or Google Sheets',
      icon: FileText,
      color: 'bg-green-100 text-green-600'
    },
    {
      type: 'json' as const,
      title: 'JSON Data',
      description: 'Export as JSON file for developers',
      icon: Database,
      color: 'bg-blue-100 text-blue-600'
    },
    {
      type: 'summary' as const,
      title: 'Summary Report',
      description: 'Export a formatted summary report',
      icon: BarChart3,
      color: 'bg-purple-100 text-purple-600'
    }
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="bg-white rounded-2xl p-6 w-full max-w-md"
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <Download className="w-5 h-5 text-blue-600" />
                </div>
                <h2 className="text-xl font-bold text-gray-900">Export Data</h2>
              </div>
              <button
                onClick={onClose}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="space-y-3">
              {exportOptions.map((option) => {
                const Icon = option.icon;
                return (
                  <motion.button
                    key={option.type}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleExport(option.type)}
                    disabled={isExporting}
                    className="w-full p-4 border border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-colors text-left disabled:opacity-50"
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`p-2 rounded-lg ${option.color}`}>
                        <Icon className="w-5 h-5" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-900">{option.title}</h3>
                        <p className="text-sm text-gray-600">{option.description}</p>
                      </div>
                    </div>
                  </motion.button>
                );
              })}
            </div>

            <div className="mt-6 p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-600">
                <strong>{expenses.length}</strong> expenses will be exported
              </p>
            </div>

            {isExporting && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="mt-4 text-center"
              >
                <div className="inline-flex items-center space-x-2 text-blue-600">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
                  <span className="text-sm">Exporting...</span>
                </div>
              </motion.div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default ExportModal;