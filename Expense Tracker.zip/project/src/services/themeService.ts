import { Theme, UserPreferences } from '../types/expense';

const PREFERENCES_KEY = 'expense_tracker_preferences';

export const THEMES: Record<string, Theme> = {
  light: {
    name: 'Light',
    primary: '#3B82F6',
    secondary: '#8B5CF6',
    accent: '#10B981',
    background: '#F8FAFC',
    surface: '#FFFFFF',
    text: '#1F2937'
  },
  dark: {
    name: 'Dark',
    primary: '#60A5FA',
    secondary: '#A78BFA',
    accent: '#34D399',
    background: '#0F172A',
    surface: '#1E293B',
    text: '#F1F5F9'
  },
  ocean: {
    name: 'Ocean',
    primary: '#0EA5E9',
    secondary: '#06B6D4',
    accent: '#14B8A6',
    background: '#F0F9FF',
    surface: '#FFFFFF',
    text: '#0C4A6E'
  },
  sunset: {
    name: 'Sunset',
    primary: '#F59E0B',
    secondary: '#EF4444',
    accent: '#EC4899',
    background: '#FFFBEB',
    surface: '#FFFFFF',
    text: '#92400E'
  },
  forest: {
    name: 'Forest',
    primary: '#059669',
    secondary: '#047857',
    accent: '#65A30D',
    background: '#F0FDF4',
    surface: '#FFFFFF',
    text: '#064E3B'
  }
};

class ThemeService {
  private preferences: UserPreferences = {
    currency: 'INR', // Default to Indian Rupees
    theme: 'light',
    dateFormat: 'IN', // Default to Indian date format
    notifications: true,
    autoCategories: true
  };

  constructor() {
    this.loadPreferences();
  }

  private loadPreferences(): void {
    try {
      const stored = localStorage.getItem(PREFERENCES_KEY);
      if (stored) {
        this.preferences = { ...this.preferences, ...JSON.parse(stored) };
      }
    } catch (error) {
      console.error('Failed to load preferences:', error);
    }
  }

  private savePreferences(): void {
    try {
      localStorage.setItem(PREFERENCES_KEY, JSON.stringify(this.preferences));
    } catch (error) {
      console.error('Failed to save preferences:', error);
    }
  }

  getPreferences(): UserPreferences {
    return { ...this.preferences };
  }

  updatePreferences(updates: Partial<UserPreferences>): void {
    this.preferences = { ...this.preferences, ...updates };
    this.savePreferences();
    this.applyTheme();
  }

  getCurrentTheme(): Theme {
    return THEMES[this.preferences.theme] || THEMES.light;
  }

  applyTheme(): void {
    const theme = this.getCurrentTheme();
    const root = document.documentElement;
    
    root.style.setProperty('--color-primary', theme.primary);
    root.style.setProperty('--color-secondary', theme.secondary);
    root.style.setProperty('--color-accent', theme.accent);
    root.style.setProperty('--color-background', theme.background);
    root.style.setProperty('--color-surface', theme.surface);
    root.style.setProperty('--color-text', theme.text);
  }

  formatDate(date: string | Date): string {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    
    switch (this.preferences.dateFormat) {
      case 'IN':
        return dateObj.toLocaleDateString('en-IN', {
          day: '2-digit',
          month: '2-digit',
          year: 'numeric'
        });
      case 'EU':
        return dateObj.toLocaleDateString('en-GB', {
          day: '2-digit',
          month: '2-digit',
          year: 'numeric'
        });
      default:
        return dateObj.toLocaleDateString('en-US');
    }
  }
}

export const themeService = new ThemeService();