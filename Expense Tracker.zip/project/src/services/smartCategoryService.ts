import { ExpenseCategory } from '../types/expense';

interface CategoryKeywords {
  [key: string]: string[];
}

const CATEGORY_KEYWORDS: CategoryKeywords = {
  Food: [
    'restaurant', 'cafe', 'coffee', 'pizza', 'burger', 'food', 'grocery', 'supermarket',
    'mcdonalds', 'kfc', 'subway', 'dominos', 'zomato', 'swiggy', 'uber eats',
    'breakfast', 'lunch', 'dinner', 'snack', 'meal', 'kitchen', 'dining',
    'chai', 'tea', 'samosa', 'dosa', 'idli', 'biryani', 'thali', 'paratha',
    'big bazaar', 'reliance fresh', 'more', 'dmart', 'haldirams', 'barbeque nation'
  ],
  Transport: [
    'uber', 'ola', 'taxi', 'bus', 'metro', 'train', 'flight', 'gas', 'petrol',
    'fuel', 'parking', 'toll', 'auto', 'rickshaw', 'bike', 'car', 'transport',
    'bmtc', 'best', 'dtc', 'local train', 'rapido', 'bounce', 'yulu'
  ],
  Health: [
    'hospital', 'doctor', 'pharmacy', 'medicine', 'medical', 'clinic', 'health',
    'dentist', 'checkup', 'prescription', 'apollo', 'fortis', 'max', 'aiims',
    'medplus', 'netmeds', '1mg', 'pharmeasy'
  ],
  Entertainment: [
    'movie', 'cinema', 'netflix', 'spotify', 'game', 'concert', 'show', 'theater',
    'entertainment', 'fun', 'party', 'club', 'bar', 'pvr', 'inox', 'youtube',
    'hotstar', 'prime video', 'zee5', 'sony liv', 'voot', 'jio cinema'
  ],
  Shopping: [
    'amazon', 'flipkart', 'myntra', 'shopping', 'mall', 'store', 'clothes',
    'electronics', 'mobile', 'laptop', 'shoes', 'fashion', 'online', 'purchase',
    'ajio', 'nykaa', 'meesho', 'snapdeal', 'paytm mall', 'jiomart'
  ],
  Bills: [
    'electricity', 'water', 'gas', 'internet', 'phone', 'mobile', 'bill',
    'utility', 'rent', 'maintenance', 'insurance', 'loan', 'emi', 'payment',
    'mseb', 'bses', 'airtel', 'jio', 'vi', 'bsnl', 'tata sky', 'dish tv'
  ],
  Education: [
    'school', 'college', 'university', 'course', 'book', 'education', 'tuition',
    'fees', 'exam', 'certification', 'training', 'workshop', 'seminar',
    'byju', 'unacademy', 'vedantu', 'white hat jr', 'coursera', 'udemy'
  ],
  Travel: [
    'hotel', 'flight', 'train', 'bus', 'travel', 'vacation', 'trip', 'tour',
    'booking', 'makemytrip', 'goibibo', 'airbnb', 'oyo', 'resort',
    'cleartrip', 'ixigo', 'redbus', 'treebo', 'fab hotels', 'irctc'
  ]
};

class SmartCategoryService {
  suggestCategory(title: string, notes?: string): ExpenseCategory {
    const text = `${title} ${notes || ''}`.toLowerCase();
    
    // Score each category based on keyword matches
    const scores: Record<string, number> = {};
    
    Object.entries(CATEGORY_KEYWORDS).forEach(([category, keywords]) => {
      scores[category] = 0;
      keywords.forEach(keyword => {
        if (text.includes(keyword)) {
          scores[category] += keyword.length; // Longer keywords get higher weight
        }
      });
    });
    
    // Find the category with the highest score
    const bestCategory = Object.entries(scores).reduce((best, [category, score]) => {
      return score > best.score ? { category, score } : best;
    }, { category: 'Other', score: 0 });
    
    return bestCategory.category as ExpenseCategory;
  }

  getConfidenceLevel(title: string, suggestedCategory: string, notes?: string): number {
    const text = `${title} ${notes || ''}`.toLowerCase();
    const keywords = CATEGORY_KEYWORDS[suggestedCategory] || [];
    
    let matches = 0;
    keywords.forEach(keyword => {
      if (text.includes(keyword)) {
        matches++;
      }
    });
    
    return Math.min(matches / 3, 1); // Max confidence at 3+ keyword matches
  }

  addCustomKeyword(category: string, keyword: string): void {
    if (CATEGORY_KEYWORDS[category]) {
      CATEGORY_KEYWORDS[category].push(keyword.toLowerCase());
    }
  }
}

export const smartCategoryService = new SmartCategoryService();