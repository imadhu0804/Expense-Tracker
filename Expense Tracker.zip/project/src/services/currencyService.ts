import { CurrencyRate } from '../types/expense';

const CURRENCY_STORAGE_KEY = 'expense_tracker_currency_rates';
const LAST_UPDATE_KEY = 'expense_tracker_currency_last_update';

// Updated exchange rates with INR as base currency
const MOCK_RATES: CurrencyRate = {
  INR: 1,
  USD: 0.012, // 1 INR = 0.012 USD
  EUR: 0.011, // 1 INR = 0.011 EUR  
  GBP: 0.0095 // 1 INR = 0.0095 GBP
};

class CurrencyService {
  private rates: CurrencyRate = MOCK_RATES;

  async fetchRates(): Promise<CurrencyRate> {
    try {
      // Check if we have cached rates from today
      const lastUpdate = localStorage.getItem(LAST_UPDATE_KEY);
      const today = new Date().toDateString();
      
      if (lastUpdate === today) {
        const cached = localStorage.getItem(CURRENCY_STORAGE_KEY);
        if (cached) {
          this.rates = JSON.parse(cached);
          return this.rates;
        }
      }

      // In production, replace with real API call
      // const response = await fetch('https://api.exchangerate-api.com/v4/latest/INR');
      // const data = await response.json();
      
      // For demo, add some random variation to mock rates
      const variation = 0.02; // 2% variation
      this.rates = {
        INR: 1,
        USD: MOCK_RATES.USD * (1 + (Math.random() - 0.5) * variation),
        EUR: MOCK_RATES.EUR * (1 + (Math.random() - 0.5) * variation),
        GBP: MOCK_RATES.GBP * (1 + (Math.random() - 0.5) * variation)
      };

      // Cache the rates
      localStorage.setItem(CURRENCY_STORAGE_KEY, JSON.stringify(this.rates));
      localStorage.setItem(LAST_UPDATE_KEY, today);

      return this.rates;
    } catch (error) {
      console.error('Failed to fetch currency rates:', error);
      return MOCK_RATES;
    }
  }

  convert(amount: number, from: keyof CurrencyRate, to: keyof CurrencyRate): number {
    if (from === to) return amount;
    
    // Convert to INR first, then to target currency
    const inrAmount = amount / this.rates[from];
    return inrAmount * this.rates[to];
  }

  formatCurrency(amount: number, currency: keyof CurrencyRate): string {
    const symbols = {
      INR: '₹',
      USD: '$',
      EUR: '€',
      GBP: '£'
    };

    const locales = {
      INR: 'en-IN',
      USD: 'en-US',
      EUR: 'de-DE',
      GBP: 'en-GB'
    };

    return new Intl.NumberFormat(locales[currency], {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: currency === 'INR' ? 0 : 2
    }).format(amount);
  }

  getRates(): CurrencyRate {
    return this.rates;
  }
}

export const currencyService = new CurrencyService();