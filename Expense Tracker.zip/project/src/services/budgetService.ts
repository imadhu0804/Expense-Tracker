import { BudgetGoal } from '../types/expense';

const BUDGET_STORAGE_KEY = 'expense_tracker_budgets';

class BudgetService {
  private getBudgets(): BudgetGoal[] {
    try {
      const stored = localStorage.getItem(BUDGET_STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  }

  private saveBudgets(budgets: BudgetGoal[]): void {
    localStorage.setItem(BUDGET_STORAGE_KEY, JSON.stringify(budgets));
  }

  async getBudgetForMonth(category: string, month: number, year: number): Promise<BudgetGoal | null> {
    const budgets = this.getBudgets();
    return budgets.find(b => b.category === category && b.month === `${year}-${month.toString().padStart(2, '0')}`) || null;
  }

  async getAllBudgets(): Promise<BudgetGoal[]> {
    return this.getBudgets();
  }

  async setBudget(category: string, monthlyLimit: number, month: number, year: number): Promise<BudgetGoal> {
    const budgets = this.getBudgets();
    const monthStr = `${year}-${month.toString().padStart(2, '0')}`;
    
    const existingIndex = budgets.findIndex(b => 
      b.category === category && b.month === monthStr
    );

    const budget: BudgetGoal = {
      id: existingIndex >= 0 ? budgets[existingIndex].id : Date.now(),
      category,
      monthlyLimit,
      currentSpent: existingIndex >= 0 ? budgets[existingIndex].currentSpent : 0,
      month: monthStr,
      year
    };

    if (existingIndex >= 0) {
      budgets[existingIndex] = budget;
    } else {
      budgets.push(budget);
    }

    this.saveBudgets(budgets);
    return budget;
  }

  async updateSpentAmount(category: string, month: number, year: number, amount: number): Promise<void> {
    const budgets = this.getBudgets();
    const monthStr = `${year}-${month.toString().padStart(2, '0')}`;
    
    const budget = budgets.find(b => b.category === category && b.month === monthStr);
    if (budget) {
      budget.currentSpent = amount;
      this.saveBudgets(budgets);
    }
  }

  async deleteBudget(id: number): Promise<void> {
    const budgets = this.getBudgets();
    const filtered = budgets.filter(b => b.id !== id);
    this.saveBudgets(filtered);
  }
}

export const budgetService = new BudgetService();