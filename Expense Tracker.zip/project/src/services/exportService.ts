import { saveAs } from 'file-saver';
import { Expense } from '../types/expense';
import { formatCurrency, formatDisplayDate } from '../utils/dateHelpers';

class ExportService {
  exportToCSV(expenses: Expense[], filename: string = 'expenses.csv'): void {
    const headers = ['ID', 'Title', 'Amount', 'Date', 'Category', 'Notes', 'Created At'];
    const csvContent = [
      headers.join(','),
      ...expenses.map(expense => [
        expense.id,
        `"${expense.title}"`,
        expense.amount,
        expense.date,
        expense.category,
        `"${expense.notes || ''}"`,
        expense.createdAt || ''
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    saveAs(blob, filename);
  }

  exportToJSON(expenses: Expense[], filename: string = 'expenses.json'): void {
    const jsonContent = JSON.stringify(expenses, null, 2);
    const blob = new Blob([jsonContent], { type: 'application/json;charset=utf-8;' });
    saveAs(blob, filename);
  }

  generateSummaryReport(expenses: Expense[]): string {
    const totalAmount = expenses.reduce((sum, exp) => sum + exp.amount, 0);
    const categoryTotals: Record<string, number> = {};
    
    expenses.forEach(expense => {
      categoryTotals[expense.category] = (categoryTotals[expense.category] || 0) + expense.amount;
    });

    const report = [
      'EXPENSE SUMMARY REPORT',
      '======================',
      '',
      `Total Expenses: ${formatCurrency(totalAmount)}`,
      `Number of Transactions: ${expenses.length}`,
      `Average Transaction: ${formatCurrency(totalAmount / expenses.length || 0)}`,
      '',
      'CATEGORY BREAKDOWN:',
      '-------------------',
      ...Object.entries(categoryTotals)
        .sort(([,a], [,b]) => b - a)
        .map(([category, amount]) => 
          `${category}: ${formatCurrency(amount)} (${((amount / totalAmount) * 100).toFixed(1)}%)`
        ),
      '',
      `Report generated on: ${formatDisplayDate(new Date())}`
    ].join('\n');

    return report;
  }

  exportSummaryReport(expenses: Expense[], filename: string = 'expense-summary.txt'): void {
    const report = this.generateSummaryReport(expenses);
    const blob = new Blob([report], { type: 'text/plain;charset=utf-8;' });
    saveAs(blob, filename);
  }
}

export const exportService = new ExportService();