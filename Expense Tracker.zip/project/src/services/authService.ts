const AUTH_STORAGE_KEY = 'expense_tracker_auth';

export interface AuthState {
  isAuthenticated: boolean;
  pin?: string;
  lastLogin?: string;
}

class AuthService {
  private getAuthState(): AuthState {
    try {
      const stored = localStorage.getItem(AUTH_STORAGE_KEY);
      return stored ? JSON.parse(stored) : { isAuthenticated: false };
    } catch {
      return { isAuthenticated: false };
    }
  }

  private saveAuthState(state: AuthState): void {
    localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(state));
  }

  isAuthenticated(): boolean {
    const state = this.getAuthState();
    return state.isAuthenticated;
  }

  hasPin(): boolean {
    const state = this.getAuthState();
    return !!state.pin;
  }

  setupPin(pin: string): void {
    const state: AuthState = {
      isAuthenticated: true,
      pin: btoa(pin), // Simple encoding
      lastLogin: new Date().toISOString()
    };
    this.saveAuthState(state);
  }

  authenticate(pin: string): boolean {
    const state = this.getAuthState();
    if (state.pin && btoa(pin) === state.pin) {
      state.isAuthenticated = true;
      state.lastLogin = new Date().toISOString();
      this.saveAuthState(state);
      return true;
    }
    return false;
  }

  logout(): void {
    const state = this.getAuthState();
    state.isAuthenticated = false;
    this.saveAuthState(state);
  }

  resetPin(): void {
    localStorage.removeItem(AUTH_STORAGE_KEY);
  }
}

export const authService = new AuthService();