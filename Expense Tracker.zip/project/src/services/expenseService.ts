import { Expense, ExpenseFormData, ExpenseFilters } from '../types/expense';

// Mock service using localStorage
const STORAGE_KEY = 'expense_tracker_data';

// Helper function to get data from localStorage
const getStoredExpenses = (): Expense[] => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Error reading from localStorage:', error);
    return [];
  }
};

// Helper function to save data to localStorage
const saveExpenses = (expenses: Expense[]): void => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(expenses));
  } catch (error) {
    console.error('Error saving to localStorage:', error);
    throw new Error('Failed to save data');
  }
};

// Generate sample data if none exists
const initializeSampleData = (): void => {
  // Clear any existing data to ensure fresh start
  localStorage.removeItem(STORAGE_KEY);
  return;
};

// Simulate API delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const expenseService = {
  // Get all expenses
  getAllExpenses: async (filters?: ExpenseFilters): Promise<Expense[]> => {
    try {
      await delay(300); // Simulate network delay
      
      initializeSampleData();
      let expenses = getStoredExpenses();

      // Apply filters
      if (filters?.startDate) {
        expenses = expenses.filter(expense => expense.date >= filters.startDate!);
      }

      if (filters?.endDate) {
        expenses = expenses.filter(expense => expense.date <= filters.endDate!);
      }

      if (filters?.category) {
        expenses = expenses.filter(expense => expense.category === filters.category);
      }

      if (filters?.search) {
        const searchTerm = filters.search.toLowerCase();
        expenses = expenses.filter(expense => 
          expense.title.toLowerCase().includes(searchTerm) ||
          expense.notes?.toLowerCase().includes(searchTerm)
        );
      }

      return expenses;
    } catch (error) {
      console.error('Error fetching expenses:', error);
      throw new Error('Failed to fetch expenses');
    }
  },

  // Get expense by ID
  getExpenseById: async (id: number): Promise<Expense> => {
    try {
      await delay(200);
      
      const expenses = getStoredExpenses();
      const expense = expenses.find(exp => exp.id === id);
      
      if (!expense) {
        throw new Error('Expense not found');
      }
      
      return expense;
    } catch (error) {
      console.error('Error fetching expense:', error);
      throw error;
    }
  },

  // Create new expense
  createExpense: async (expenseData: ExpenseFormData): Promise<Expense> => {
    try {
      await delay(400);
      
      const expenses = getStoredExpenses();
      const newId = Math.max(0, ...expenses.map(exp => exp.id)) + 1;
      const now = new Date().toISOString();
      
      const newExpense: Expense = {
        id: newId,
        ...expenseData,
        createdAt: now,
        updatedAt: now
      };
      
      expenses.push(newExpense);
      saveExpenses(expenses);
      
      return newExpense;
    } catch (error) {
      console.error('Error creating expense:', error);
      throw new Error('Failed to create expense');
    }
  },

  // Update expense
  updateExpense: async (id: number, expenseData: ExpenseFormData): Promise<Expense> => {
    try {
      await delay(400);
      
      const expenses = getStoredExpenses();
      const index = expenses.findIndex(exp => exp.id === id);
      
      if (index === -1) {
        throw new Error('Expense not found');
      }
      
      const updatedExpense: Expense = {
        ...expenses[index],
        ...expenseData,
        updatedAt: new Date().toISOString()
      };
      
      expenses[index] = updatedExpense;
      saveExpenses(expenses);
      
      return updatedExpense;
    } catch (error) {
      console.error('Error updating expense:', error);
      throw new Error('Failed to update expense');
    }
  },

  // Delete expense
  deleteExpense: async (id: number): Promise<void> => {
    try {
      await delay(300);
      
      const expenses = getStoredExpenses();
      const filteredExpenses = expenses.filter(exp => exp.id !== id);
      
      if (filteredExpenses.length === expenses.length) {
        throw new Error('Expense not found');
      }
      
      saveExpenses(filteredExpenses);
    } catch (error) {
      console.error('Error deleting expense:', error);
      throw new Error('Failed to delete expense');
    }
  }
};