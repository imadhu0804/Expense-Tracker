import { RecurringExpense } from '../types/expense';
import { addDays, addWeeks, addMonths, isBefore, parseISO } from 'date-fns';

const RECURRING_STORAGE_KEY = 'expense_tracker_recurring';

class RecurringExpenseService {
  private getRecurringExpenses(): RecurringExpense[] {
    try {
      const stored = localStorage.getItem(RECURRING_STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  }

  private saveRecurringExpenses(expenses: RecurringExpense[]): void {
    localStorage.setItem(RECURRING_STORAGE_KEY, JSON.stringify(expenses));
  }

  async getAllRecurring(): Promise<RecurringExpense[]> {
    return this.getRecurringExpenses();
  }

  async createRecurring(expense: Omit<RecurringExpense, 'id'>): Promise<RecurringExpense> {
    const expenses = this.getRecurringExpenses();
    const newExpense: RecurringExpense = {
      ...expense,
      id: Date.now()
    };
    
    expenses.push(newExpense);
    this.saveRecurringExpenses(expenses);
    return newExpense;
  }

  async updateRecurring(id: number, updates: Partial<RecurringExpense>): Promise<void> {
    const expenses = this.getRecurringExpenses();
    const index = expenses.findIndex(e => e.id === id);
    
    if (index >= 0) {
      expenses[index] = { ...expenses[index], ...updates };
      this.saveRecurringExpenses(expenses);
    }
  }

  async deleteRecurring(id: number): Promise<void> {
    const expenses = this.getRecurringExpenses();
    const filtered = expenses.filter(e => e.id !== id);
    this.saveRecurringExpenses(filtered);
  }

  async getDueExpenses(): Promise<RecurringExpense[]> {
    const expenses = this.getRecurringExpenses();
    const today = new Date();
    
    return expenses.filter(expense => 
      expense.isActive && isBefore(parseISO(expense.nextDue), today)
    );
  }

  calculateNextDue(frequency: RecurringExpense['frequency'], currentDate: Date): string {
    switch (frequency) {
      case 'daily':
        return addDays(currentDate, 1).toISOString().split('T')[0];
      case 'weekly':
        return addWeeks(currentDate, 1).toISOString().split('T')[0];
      case 'monthly':
        return addMonths(currentDate, 1).toISOString().split('T')[0];
      default:
        return currentDate.toISOString().split('T')[0];
    }
  }

  async processRecurringExpense(recurringId: number): Promise<void> {
    const expenses = this.getRecurringExpenses();
    const expense = expenses.find(e => e.id === recurringId);
    
    if (expense) {
      // Update next due date
      const nextDue = this.calculateNextDue(expense.frequency, new Date());
      await this.updateRecurring(recurringId, { nextDue });
    }
  }
}

export const recurringExpenseService = new RecurringExpenseService();